<?php
include 'includes/DatabaseConnection.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!isset($_POST['id']) || empty(trim($_POST['id']))) {
            throw new Exception('Module ID is missing.');
        }

        $sql = 'UPDATE module SET ModuleName = :ModuleName WHERE id = :id';
        $stmt = $pdo->prepare($sql);

        $stmt->bindValue(':id', $_POST['id'], PDO::PARAM_INT);
        $stmt->bindValue(':ModuleName', $_POST['ModuleName']);
        $stmt->execute();

        header('Location: modules.php');
        exit;
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
} else {

    try {
        if (!isset($_GET['id']) || empty(trim($_GET['id']))) {
            throw new Exception('Module ID is missing.');
        }
        $sql = 'SELECT * FROM module WHERE id = :id';
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':id', $_GET['id'], PDO::PARAM_INT);
        $stmt->execute();
        $module = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$module) {
            throw new Exception('Module not found. Please check the ID.');
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

$title = 'Edit Module';

ob_start();
?>
<h1>Edit Module</h1>

<?php if (!empty($error)): ?>
    <p style="color: red;"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>

<?php if (isset($module) && $module): ?>
    <form action="editmodule.php" method="post">
        <input type="hidden" name="id" value="<?= htmlspecialchars($module['id'], ENT_QUOTES, 'UTF-8') ?>">
        <label for="ModuleName">Module Name:</label>
        <input type="text" name="ModuleName" id="ModuleName" value="<?= htmlspecialchars($module['ModuleName'], ENT_QUOTES, 'UTF-8') ?>" required><br><br>
        <button type="submit">Save Changes</button>
    </form>
<?php endif; ?>

<?php
$output = ob_get_clean();
include 'template/layout.html.php';
?>