<?php
//thực hiện cn(catch xử lý lỗi kết nối cơ cở dldl)
try{
    include 'includes/DatabaseConnection.php';
    include 'includes/DatabaseFunctions.php';

    $posts = allPosts($pdo);
    $title = 'posts list';
    $totalPosts = totalPosts($pdo); // trả về tất cả post 

    ob_start();
    include 'template/pulic_posts.html.php';
    $output = ob_get_clean();   
}catch(PDOException $e) {
    $title = 'An error has occured';
    $output = 'Database error:' . $e->getMessage();
}
include 'template/layout.html.php';