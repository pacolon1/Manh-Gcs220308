<?php
session_start(); 
if (isset($_GET['toggle'])) {
    $_SESSION['menu_open'] = !isset($_SESSION['menu_open']) || $_SESSION['menu_open'] == false;
}
if (!isset($_SESSION['menu_open'])) {
    $_SESSION['menu_open'] = false;
}
$title = 'Internet posts Database';
ob_start();
include 'template/home.html.php';
$output = ob_get_contents();
include 'template/layout.html.php';
?>
<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Menu Toggle</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>  
    <div class="menu-container"> 
        <div class="hamburger-menu">      
            <a href="?toggle=true">&#9776;</a> 
        </div>
        <div class="menu <?php echo $_SESSION['menu_open'] ? 'show' : ''; ?>" id="menu"> 
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="posts.php">Posts List</a></li>
                <li><a href="addpost.php">Add</a></li>
                <li><a href="users.php">User</a></li>
                <li><a href="modules.php">Module</a></li>
                <li><a href="admin/login/login.html">Admin Login</a></li>
            </ul>
        </div>
    </div>

</body>
</html>




