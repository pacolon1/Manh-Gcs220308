<?php
include 'includes/DatabaseConnection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!empty($_POST['name']) && !empty($_POST['email'])) {
            $name = trim($_POST['name']);
            $email = trim($_POST['email']);

            $sql = 'INSERT INTO user (name, email) VALUES (:name, :email)';
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':name', $name);
            $stmt->bindValue(':email', $email);
            $stmt->execute();

            header('Location: users.php'); // Quay lại danh sách người dùng
            exit;
        } else {
            $error = "Please fill in all fields.";
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}

$title = 'Add User';
ob_start();
?>

<h1>Add User</h1>
<?php if (isset($error)): ?>
<p style="color: red;"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<form action="adduser.php" method="post">
    <label for="name">Username:</label>
    <input type="text" name="name" id="name" required><br><br>
    <label for="email">Email:</label>
    <input type="email" name="email" id="email" required><br><br>
    <button type="submit">Add User</button>
</form>

<?php
$output = ob_get_clean();
include 'template/layout.html.php';
?>
