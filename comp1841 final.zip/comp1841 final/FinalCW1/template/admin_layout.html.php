<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../posts.css">
        <title><?=$title?></title>
    </head>
    <body>
        <header id="admin">
            <h1>Internet post admin area<br /></h1></header>
        <nav>
            <ul>
                <!-- <li><a href="index.php">Home</a></li> -->
                <li><a href="posts.php">Post List</a></li>
                <li><a href="addpost.php">Add A New Post</a></li>
                <li><a href="users.php">Manage User</a></li>
                <li><a href="modules.php">Manage Module</a></li>
                <li><a href="login/Logout.php">Public site/Logout</a></li>
                
            </ul>
        </nav>
        <main>
            <?=$output?>
        </main>
        <footer>&copy; IJDB 2023</footer>
    </body>
</html>