<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="posts.css">
        <title><?=$title?></title>
    </head>
    <body>
        <header><h1>Internet Post<br /></h1></header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="posts.php">Posts List</a></li>
                <li><a href="users.php">Manage User</a></li>
                <li><a href="modules.php">Manage Module</a></li>
                <li><a href="admin/login/login.html">Admin Login</a></li>
            </ul>
        </nav>
        <main>
            <?=$output?>
        </main>
        <footer>&copy; IJDB 2023</footer>
    </body>
</html>