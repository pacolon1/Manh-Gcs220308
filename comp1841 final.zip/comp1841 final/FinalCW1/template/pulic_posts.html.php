<p><?=$totalPosts?> Post have submitted to the internet post .</p>
<?php foreach($posts as $post): ?>
        <blockquote> 
        <?=htmlspecialchars($post['posttext'], ENT_QUOTES, 'UTF-8')?>
        <br /><?=htmlspecialchars($post['ModuleName'],ENT_QUOTES,'UTF-8')?>
        (by <a href="mailto: <?=htmlspecialchars($post['email'],ENT_QUOTES, 'UTF-8' );?>">
        <?=htmlspecialchars($post['name'], ENT_QUOTES, 'UTF-8'); ?></a>)
        <a href="editpost.php?id=<?=$post['id']?>">Edit</a>
        <form action="deletepost.php" method="post">
                <input type="hidden" name="id" value="<?=$post['id']?>">
                <input type="submit" value="Delete">
        </form> 
        <?php if (!empty($post['fileToUpload'])): ?>
            <img src="uploads/<?= htmlspecialchars($post['fileToUpload'], ENT_QUOTES, 'UTF-8') ?>" 
                 alt="Image for post <?= $post['id'] ?>" 
                 style="max-width: 300px; height: auto;">
        <?php endif; ?>
        
        </blockquote>
        <?php endforeach;?>

