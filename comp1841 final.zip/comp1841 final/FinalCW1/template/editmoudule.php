<form action="editmodule.php" method="post">
    <input type="hidden" name="id" value="<?= $user['id'] ?>">
    <label for="name">Username:</label>
    <input type="text" name="ModuleName" id="ModuleName" value="<?= htmlspecialchars($user['ModuleName'], ENT_QUOTES, 'UTF-8') ?>" required><br>
    <button type="submit">Update Module</button>
</form>
