<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post</title>
</head>
<body>
    <h1>Edit Post</h1>
    <form method="POST" action="editpost.php">
        <input type="hidden" name="postid" value="<?= isset($post['id']) ? htmlspecialchars($post['id'], ENT_QUOTES, 'UTF-8') : ''; ?>">
        <label for="posttext">Post Text:</label>
        <textarea id="posttext" name="posttext" rows="5" cols="50" required><?= isset($post['posttext']) ? htmlspecialchars($post['posttext'], ENT_QUOTES, 'UTF-8') : ''; ?></textarea>
        <br>
        <label for="userid">Select User:</label>
        <select name="userid" id="userid" required>
            <option value="">Select a user</option>
            <?php foreach ($users as $user): ?>
                <option value="<?= htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?>" 
                    <?= isset($post['userid']) && $post['userid'] == $user['id'] ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8'); ?>               
                </option>
            <?php endforeach; ?>
        </select>
        <br>
        <label for="moduleid">Select Module:</label>
        <select name="moduleid" id="moduleid" required>
            <option value="">Select a module</option>
            <?php foreach ($modules as $module): ?>
                <option value="<?= htmlspecialchars($module['id'], ENT_QUOTES, 'UTF-8'); ?>" 
                    <?= isset($post['moduleid']) && $post['moduleid'] == $module['id'] ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($module['ModuleName'], ENT_QUOTES, 'UTF-8'); ?>               
                </option>
            <?php endforeach; ?>
        </select>
        <br>
        <input type="submit" name="submit" value="Update">
    </form>
</body>
</html>