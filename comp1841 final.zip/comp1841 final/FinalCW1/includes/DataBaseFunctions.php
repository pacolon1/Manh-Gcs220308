<?php
function totalPosts($pdo){
    $query = query($pdo,'SELECT COUNT(*) FROM post');
    $row = $query->fetch();
    return $row[0];
}
function query($pdo,$sql,$parameters = []){
    $query = $pdo->prepare($sql);
    $query->execute($parameters);
    return $query;
}
function getPost($pdo, $id) {
    $sql = 'SELECT post.*, user.name AS username, module.ModuleName AS ModuleName
            FROM post
            JOIN user ON post.userid = user.id
            JOIN module ON post.moduleid = module.id
            WHERE post.id = :id';
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
function updatePost($pdo, $id, $posttext, $userid, $moduleid) {
    $sql = 'UPDATE post
            SET posttext = :posttext, userid = :userid, moduleid = :moduleid 
            WHERE id = :id';
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->bindValue(':posttext', $posttext, PDO::PARAM_STR);
    $stmt->bindValue(':userid', $userid, PDO::PARAM_INT);
    $stmt->bindValue(':moduleid', $moduleid, PDO::PARAM_INT);
    $stmt->execute();
}

function deletePost($pdo,$id){
    $parameters = [':id'=>$id];
    query($pdo,'DELETE FROM post WHERE id =:id',$parameters);
}

function insertPost($pdo, $posttext, $userid, $moduleid, $fileToUpload) {
    $query = 'INSERT INTO post (posttext, postdate, userid, moduleid, fileToUpload)
              VALUES (:posttext, CURDATE(), :userid, :moduleid, :fileToUpload)';
    $parameters = [
        ':posttext' => $posttext, 
        ':userid' => $userid, 
        ':moduleid' => $moduleid,
        ':fileToUpload' => $fileToUpload
    ];
    
    query($pdo, $query, $parameters);
}

function allUsers($pdo) {
    $sql = 'SELECT * FROM user';
    return query($pdo, $sql)->fetchAll();
}
function allModules($pdo) {
    $sql = 'SELECT * FROM module';
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function allPosts($pdo) {
    $query = 'SELECT post.id, posttext, fileToUpload, `name`, email, ModuleName
              FROM post
              INNER JOIN user ON userid = user.id
              INNER JOIN module ON moduleid = module.id';
    $posts = query($pdo, $query);
    return $posts->fetchAll();
}

function findById(PDO $pdo, string $table, int $id): array {
    $query = 'SELECT * FROM ' . $table . ' WHERE id = :id';
    $stmt = $pdo->prepare($query);
    $stmt->execute([':id' => $id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
function getUserIdByName($pdo, $name) {
    $sql = 'SELECT id FROM user WHERE name = :name';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':name' => $name]);
    return $stmt->fetchColumn();
}

function getModuleIdByName($pdo, $name) {
    $sql = 'SELECT id FROM module WHERE ModuleName = :name';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':name' => $name]);
    return $stmt->fetchColumn();
}

function getPostWithDetails($pdo, $id) {
    $sql = 'SELECT post.id, post.posttext, user.name AS username, module.ModuleName AS ModuleName
            FROM post
            LEFT JOIN user ON post.userid = user.id
            LEFT JOIN module ON post.moduleid = module.id
            WHERE post.id = :id';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}


