<?php 
$pdo = new PDO('mysql:host=localhost;dbname=week4;charset=utf8mb4','root','');