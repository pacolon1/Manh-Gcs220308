<?php
include 'includes/DatabaseConnection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Kiểm tra xem dữ liệu có tồn tại và không rỗng
        if (!empty($_POST['ModuleName'])) {
            $ModuleName = trim($_POST['ModuleName']);

            // Chuẩn bị câu lệnh SQL để thêm module mới vào cơ sở dữ liệu
            $sql = 'INSERT INTO module (ModuleName) VALUES (:ModuleName)';
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':ModuleName', $ModuleName);
            $stmt->execute();

            // Chuyển hướng về danh sách modules sau khi thêm thành công
            header('Location: modules.php');
            exit;
        } else {
            $error = "Please fill in all fields.";
        }
    } catch (PDOException $e) {
        // Bắt lỗi nếu có vấn đề với cơ sở dữ liệu
        $error = "Database error: " . $e->getMessage();
    }
}


$title = 'Add Module';
ob_start();
?>

<h1>Add Module</h1> 
<?php if (isset($error)): ?>
<p style="color: red;"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<form action="addmodule.php" method="post">
    <label for="ModuleName">Modulename:</label>
    <input type="text" name="ModuleName" id="ModuleName" required><br><br>
    <button type="submit">Add Module</button>
</form>

<?php
$output = ob_get_clean();
include 'template/layout.html.php';
?>
