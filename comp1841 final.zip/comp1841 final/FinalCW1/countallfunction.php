<?php 
include 'includes/DatabaseConnection.php';
function totalPosts($pdo){//khai báo totaltotal
    $query = $pdo->prepare('SELECT COUNT(*) FROM post');//đếm số bài đăngđăng
    $query->execute();
    $row = $query->fetch();
    return $row[0];// kq hàm postpost
}
echo totalPosts($pdo); //gọi hàm TP in kq trả về postpost = echo ,
