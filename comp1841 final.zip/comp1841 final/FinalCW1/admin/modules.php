<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

// Lấy danh sách modules
$modules = allModules($pdo); // Lấy danh sách tất cả modules
$title = 'Manage Modules';
ob_start();
?>

<h1>Manage Modules</h1>
<a href="addmodule.php" class="button">Add Module</a>

<table>
    <tr>
        <th>Module Name</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($modules as $module): ?>
    <tr> 
        <td><?= htmlspecialchars($module['ModuleName'], ENT_QUOTES, 'UTF-8') ?></td>  
        <td>
            <a href="editmodule.php?id=<?= $module['id'] ?>">Edit</a>
            <form action="deletemodule.php" method="post" style="display:inline;">
                <input type="hidden" name="id" value="<?= $module['id'] ?>">
                <input type="submit" value="Delete">
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<?php
$output = ob_get_clean(); // gán nd vào biến $output(obstart lưu nd xuất ra )
include '../template/admin_layout.html.php';
?>
