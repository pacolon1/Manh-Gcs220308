<?php

if(isset($_POST['posttext'])){
    try{
        include '../includes/DatabaseConnection.php';
        include '../includes/DatabaseFunctions.php';
    
        insertPost($pdo,$_POST['posttext'],$_POST['users'],$_POST['modules'],$_FILES['fileToUpload']);
        include '../includes/uploadFile.php';
        header('location: posts.php');
    }catch(PDOException $e){
        $title = 'an error has occurred';
        $output = 'Database error:' . $e->getMessage();
    }
}else{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';
    $title = 'add a new post';
    //$sql_a = 'SELECT * FROM author';
    $users = allUsers($pdo);
    //$sql_c = 'SELECT * FROM category';
    $modules = allModules($pdo);
    ob_start();
    include '../template/addpost.html.php';
    $output = ob_get_clean();
}

if (isset($_FILES['fileToUpload']) && $_FILES['fileToUpload']['error'] == UPLOAD_ERR_OK) {
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Validate file type and size
    if ($_FILES["fileToUpload"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
    } elseif (!in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            $uploadedFileName = $_FILES["fileToUpload"]["name"];
        } else {
            echo "Error uploading the file.";
            $uploadedFileName = null;
        }
    }
} else {
    $uploadedFileName = null;
}

// Insert post into database
if (!empty($_POST['posttext'])) {
}



include '../template/admin_layout.html.php';