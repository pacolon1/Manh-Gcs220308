<?php 
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['posttext'], $_POST['postid'], $_POST['userid'], $_POST['moduleid'])) {
        // Validate input values
        $postid = $_POST['postid'];
        $posttext = $_POST['posttext'];
        $userid = $_POST['userid'];
        $moduleid = $_POST['moduleid'];

        // Perform the update
        updatePost($pdo, $postid, $posttext, $userid, $moduleid);

        // Redirect after successful update
        header('Location: posts.php');
        exit;
    } elseif (isset($_GET['id'])) {
        // Fetch post, users, and modules to display in the edit form
        $post = getPost($pdo, $_GET['id']);
        $title = 'Edit post';
        $users = allUsers($pdo);
        $modules = allModules($pdo);

        ob_start();
        include '../template/editpost.html.php';
        $output = ob_get_clean();
    } else {
        throw new Exception('Post ID is missing.');
    }
} catch (PDOException $e) {
    $title = 'An error has occurred';
    $output = 'Error editing post: ' . $e->getMessage();
} catch (Exception $e) {
    $title = 'An error has occurred';
    $output = $e->getMessage();
}

include '../template/admin_layout.html.php';
