<?php
try{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';
    deletepost($pdo,$_POST['id']);
    // $sql = 'DELETE FROM joke WHERE id = :id';
    // $stmt = $pdo->prepare($sql);
    // $stmt ->bindValue(':id',$_POST['id']);
    // $stmt->execute();
    header('location: posts.php');
}catch(PDOException $e){
$title = 'An error has occured';
$output = 'unable to connect to delete post:' .$e->getMessage();
}
include '../template/admin_layout.html.php';