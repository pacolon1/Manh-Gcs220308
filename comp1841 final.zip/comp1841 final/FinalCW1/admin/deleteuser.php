<?php
include '../includes/DatabaseConnection.php';

// chỉ xử lý khi yêu cầu là post
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $sql = 'DELETE FROM user WHERE id = :id';
        $stmt = $pdo->prepare($sql);//xóa từ bảng user vs đk id khớpkhớp
        $stmt->bindValue(':id', $_POST['id'], PDO::PARAM_INT);//gán id từ biểu mẫu , xác định id số nguyênnguyên
        $stmt->execute();//thực hiện câu lệnh

        header('Location: users.php'); // Quay lại danh sách người dùng
        exit;
    } catch (PDOException $e) {
        echo 'Database error: ' . $e->getMessage();
    }//thống báo lỗilỗi
}
?>
