<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

$users = allUsers($pdo); // Lấy danh sách tất cả người dùng
$title = 'Manage Users';
ob_start();
?>

<h1>Manage Users</h1>
<a href="adduser.php" class="button">Add User</a>


<!-- tạo bảng -->
<table> 
    <tr>
        <th>Username</th>
        <th>Email</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($users as $user): ?> 
    <tr> 
        <td><?= htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8') ?></td>
        <td><?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8') ?></td>
        <td>
            <a href="edituser.php?id=<?= $user['id'] ?>">Edit</a>
            <form action="deleteuser.php" method="post" style="display:inline;">
                <input type="hidden" name="id" value="<?= $user['id'] ?>">
                <input type="submit" value="Delete">
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<?php
$output = ob_get_clean(); //lưu (obstart bộ đệm)
include '../template/admin_layout.html.php';
?>
